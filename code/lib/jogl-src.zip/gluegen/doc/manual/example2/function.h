float process_data(float* data, int n);
void set_global_data(float* data);
float process_global_data(int n);
